/* Includes ------------------------------------------------------------------*/

#include "platform_config.h"

/* Private function prototypes -----------------------------------------------*/
void RF_Data_Confirm(unsigned char CNT);
